Simple Markdown test with non-ASCII string.
