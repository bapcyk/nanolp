Markdown test with:
    - usage of LP source via HTTP
    - force of format when auto-detection is impossible (see 'fmt:md')
    - output into different directory with auto-creation (see 'here/out.out')
    - cross-referencies generation
    - processing test file via HTTP (see 'example.sh')
    - HTTP no login
