Test of:
    - Asciidoc
    - Creole
    - Markdown
    - ReStructuredText
    - Txt2Tags
    - TeX/LaTeX
