OpenOffice test with non-ASCII string in code chunk (and output
file sure).
