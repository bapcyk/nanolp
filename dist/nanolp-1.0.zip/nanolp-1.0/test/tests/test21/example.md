Write to:   <<file.x, out.out>> `<<=pasting>>`

Example of Literate Programming in Markdown
===========================================

Multi-part command <<mp>>: `first line`, `second line`, `third
line` and `last line`.

Now test pasting of multi-part command <<pasting>>:

    <<=mp.0>>
    <<=mp.3>>
    <<=mp.-1>>
    <<=mp.-2>>
    <<=mp.-3>>
    <<=mp.-4>>

not code
not code

Lalalalalalal
Lalalalalalal
