Markdown test with multi-part commands and indexed access to chunks.
