Markdown test with using (see command 'use') of another LP sources
(as library), mounted transparency and under another path).
