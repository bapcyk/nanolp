Markdown test with using of OpenOffice LP source (as library) with
'use' command.
