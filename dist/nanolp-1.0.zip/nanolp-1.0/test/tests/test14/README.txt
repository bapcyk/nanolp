Markdown test of event system (see 'do', 'on' command, etc.).
