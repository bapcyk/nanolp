Simple test with Markdown syntax and parameterized chunk.
