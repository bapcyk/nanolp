from nanolp.test import cases
cases.run(cases.TestExamplesDir(modpath=__file__))
