from nanolp.test import cases
cases.run(cases.TestExamplesDirViaHTTP(modpath=__file__))
