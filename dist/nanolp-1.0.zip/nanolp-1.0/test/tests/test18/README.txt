Markdown test with:
    - usage of LP source via FTP (see 'lpurlrc')
    - force of format when auto-detection is impossible (see 'fmt:md')
    - output into different directory with auto-creation (see 'here/out.out')
    - cross-referencies generation
    - processing test file via FTP (see 'example.sh')
    - FTP login with user name and password
