from nanolp.test import cases
cases.run(cases.TestExamplesDirViaFTP(modpath=__file__))
