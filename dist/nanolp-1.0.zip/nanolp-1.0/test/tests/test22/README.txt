Simple test with Markdown syntax and parameterized chunk and with
different for code and doc sections surround symbols.
