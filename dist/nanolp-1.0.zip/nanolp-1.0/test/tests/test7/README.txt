OpenOffice test with beauty styling and:
    - multipart chunks (block and inline)
    - globbing of command paths
    - joining, ending of several chunks
    - multi-styles (bolding in code block)
    - different glyphs of one ASCII symbol (i.e. ")
    - several output files
