HTML parser test with several output files.
