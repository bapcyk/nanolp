Standard sources for C
======================

Very usuable in H (header) file is guarding [[hh]]:

    #ifndef _${file}_H_
    # define _${file}_H_

and end of H-file: `#endif`.
