Mathmematic library
===================

Very usuable and simple functions [[min]]:

    int min(int a, int b) {
        if (a > b) return b;
        else return a;
    }

and [[max]]:

    int max(int a, int b) {
        if (a > b) return a;
        else return b;
    }
