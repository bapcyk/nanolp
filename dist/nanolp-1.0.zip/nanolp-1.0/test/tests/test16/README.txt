HTML parser test with:
    - cross-referencies generation
    - publishing of HTML
    - several library LP sources ('use' command)
