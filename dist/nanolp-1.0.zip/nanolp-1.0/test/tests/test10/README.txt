Markdown test with error message (syntax error detection).
