Markdown test with:
    - output to file (see 'file' command in the text)
    - empty lines in code chunk
