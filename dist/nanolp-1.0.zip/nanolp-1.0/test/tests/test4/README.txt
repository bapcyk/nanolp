Markdown test with:
    - forward chunk definition (paste of chunk is BEFORE it's definition)
    - several output files
    - globbing of command paths (see 'incl.*')
    - joining of several chunks (see 'join:;\n')
    - variable substitution (as usual with '$')
