Markdown test with:
    - LP source fetching ('use' command) from zip file ('zip://...')
    - LP source fecting from crypted zip file (see 'lpurlrc')
    - LP source fetching from shell pipe (see 'shell://...' and 'cat.txt')
