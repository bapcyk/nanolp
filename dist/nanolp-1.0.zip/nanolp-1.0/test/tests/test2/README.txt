Simple Markdown test with non-standard surround symbols (see 'lprc')
and parameterized chunks. One of them uses binding of it's parameters
to it names as '*:*' ('all variable has value equals to it's name'),
so variable '$some_var' will substitute with value 'some_var'.
