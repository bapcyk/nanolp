from nanolp.test import cases
cases.run(cases.TestDocStrings())
