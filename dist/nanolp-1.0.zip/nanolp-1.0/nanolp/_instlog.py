# Installation paths log
SCRIPTS_DIR = r'c:\python33\Scripts'
PURELIB_DIR = r'c:\python33\Lib\site-packages'
DATA_DIR = r'c:\python33'
